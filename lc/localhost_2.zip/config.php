<?php
$mas =
[
    ["title" => "Главная", "link" => "index.php"],
    ["title" => "Блоги", "link" => "posts.php"],
    ["title" => "Пользователи", "link" => "users.php"],
    ["title" => "О нас", "link" => "about.php"],
    ["title" => "Вход", "link" => "login.php"],
    ["title" => "Регистрация", "link" => "register.php"],
    ["title" => "Выход", "link" => "index.php"],
];
