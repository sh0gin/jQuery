<ul>
	<li><a href="index.php">Главная</a></li>
	<li><a href="posts.php">Блоги</a></li>
	<li><a href="users.php">Пользователи</a></li>
	<li><a href="about.php">О нас</a></li>
	<li><a href="login.php">Вход</a> / <a href="register.php">Регистрация</a></li>
	<li><a href="#">Выход</a></li>
</ul>
<!-- class="colorlib-active" -->