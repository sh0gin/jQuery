<?php

$db = [
    "hostname" => 'localhost',
    "username" => 'root',
    "password" => "",
    "database" => "database_practic2",
];