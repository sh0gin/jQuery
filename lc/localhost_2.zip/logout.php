<?php
require_once "main.php";

$user->logout();
$response->redirect("index.php");