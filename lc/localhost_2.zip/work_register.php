<?php
require_once "main.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user->load($_POST);
    if ($user -> validateRegister()) {

    } else {

        if ($user->save()) {
            // $response -> redirect('index.php');
            header("Location: index.php"); exit;
        } 
    }
}