<?php

class Menu
{
    public $val;
    public $response;

    public function __construct($array, $response)
    {
        $this->val = $array;
        $this->response = $response;
    }

    public function give_html(): string
    {
        $result = "<ul>";

        foreach ($this->val as $elem)
        {

            if (array_key_exists("isGuest", $elem)) {
                if ($elem["isGuest"] == $this->response->user->isGuest) {
                    if ("/" . $elem["link"] == $_SERVER["SCRIPT_NAME"]) {
                        $result .= "<li class='colorlib-active'><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    } else {
                        $result .= "<li><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    }
                }
            } else if (array_key_exists("isAdmin", $elem)) {
                if ($elem["isAdmin"] == $this->response->user->isAdmin) {
                    if ("/" . $elem["link"] == $_SERVER["SCRIPT_NAME"]) {
                        $result .= "<li class='colorlib-active'><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    } else {
                        $result .= "<li><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    }
                }
            } else {
                    if ("/" . $elem["link"] == $_SERVER["SCRIPT_NAME"]) {
                        $result .= "<li class='colorlib-active'><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    } else {
                        $result .= "<li><a href='{$this->response->getLink($elem['link'])}'>$elem[title]</a></li>";
                    }
            }

        }
        $result .= "<ul>";
        return $result;

    }
}