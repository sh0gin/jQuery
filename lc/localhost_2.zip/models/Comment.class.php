<?php

class Comment
{
    public $id;
    public $date;
    public $autor_id;
    public $post_id;
    public $message;
    public $valid_message;

    public $user;
    public $request;
    public $post;
    public $response;

    public function __construct($user, $request, $post, $response)
    {
        $this->user = $user;
        $this->request = $request;
        $this->post = $post;
        $this->response = $response;
    }

    public function validate()
    {
        return Asists::validateDate($this);
    }

    public function load_comment($array)
    {
        Asists::loadData($this, $array);
    }

    public function findOne(?int $id = null): bool
    {
        $result = false;
        if ($id) {
            $mas = $this->user->mysql->select("select * from comment where id = '$id'");
            $this->load_comment($mas[0]);

            $this->date = Asists::format_date(new Datetime($this->date));
            $result = true;
        }

        return $result;
    }

    public function save()
    {
        $message = Asists::replace_rn($this->message);
        if ($this->user->mysql->query("INSERT into comment (autor_id, message, post_id) VALUES ('{$this->user->id}', '$message', '{$this->post->id}')")) {
            return true;
        }
        return false;
    }

    public function get_date()
    {
        return Asists::format_date($this->date);
    }

    public function get_comments(): array
    {

        $result = [];

        foreach ($this->user->mysql->select("SELECT * FROM COMMENT WHERE post_id = '{$this->request->get("id")}' ORDER BY date DESC") as $value) {
            
            $exam_user = new User($this->request, $this->user->mysql);
            $exam_user->identity($value["autor_id"]);

            $exam_post = new Post($exam_user, $this->request, $this->response);
            $exam_post->findOne($value["post_id"]);

            $exam_comment = new static($exam_user, $exam_post, $this->post, $this->response);
            $exam_comment->findOne($value['id']); 
            $result[] = $exam_comment;
        }
        return $result;
    }

    public function delete_comment($id = null){

        if ($id) {
            $this->user->mysql->query("DELETE FROM COMMENT WHERE id = '{$id}'");
        }
    }
}
