<?php

class Block
{

    public $mysql;

    public function __construct($mysql) {
        $this->mysql = $mysql;
    }

    public function ban() { // always

    }

    public function block($date, $user_id) { // time
        if (!($this->mysql->select("SELECT role FROM user where id = '$user_id'")[0]['role'])) {
            $this->mysql->query("INSERT into block (date_end, user_id)
            VALUES ('$date', '$user_id')");
            $this->mysql->query("UPDATE user SET token = NULL WHERE id = '{$user_id}'");
        }

    }
}