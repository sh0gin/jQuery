<?php
require_once __DIR__ . "/main.php";
if ($_SERVER["REQUEST_METHOD"] == "GET" && $request->get("id")) {
    $post->findOne($request->get("id"));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // if (!$request->post("message")) {
        if (!$user->isAdmin && !$user->isGuest) {
            $post->load_post($_POST);
            if ($post->validate()) {
                
            } else {
                if ($post->save()) {
                    if ($request->get("id")) {
                        $id = $request->get("id");
                    } else {
                        $id = $post->user->mysql->insert_id;
                    }
                    $post->findOne($id);

                    
                    $response->redirect("post.php", ["id" => $id]);
                }
            }
        } else {
            $response->redirect("index.php");
        }
    // } else {
    //     if (!$user->isAdmin && !$user->isGuest) {
    //         $comment->load_comment($_POST);
    //         $comment->post->findOne($request->get("id"));
    //         if ($comment->validate()) {
    //             printd($comment); die;
                
    //         } 
    //         printd($comment); die;
    //         // printd($request->post()); die;
    //     }
    // }
}
